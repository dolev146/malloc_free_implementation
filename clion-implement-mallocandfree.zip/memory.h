//
// Created by yakovkhodorkovski on 4/26/22.
//

#ifndef IMPLEMNTMALLOC_MEMORY_H
#define IMPLEMNTMALLOC_MEMORY_H

#include <sys/types.h>

void *malloc(size_t size);
void free(void *ptr);

#endif //IMPLEMNTMALLOC_MEMORY_H
